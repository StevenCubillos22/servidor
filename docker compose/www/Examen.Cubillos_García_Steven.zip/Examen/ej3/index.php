<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encontrar Máximo y Mínimo</title>
</head>

<body>
    <h2>Introduce un número :)) :</h2>
    <form action="ej3.php" method="post">
        <label for="numero1">Número 1:</label>
        <input type="number" id="numero1" name="numero1" required><br>

        

        <input type="submit" value="Calcular">
    </form>
</body>

</html>