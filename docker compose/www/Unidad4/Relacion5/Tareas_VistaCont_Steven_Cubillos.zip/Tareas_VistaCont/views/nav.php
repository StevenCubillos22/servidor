<hr/>
<nav>
    Menú de navegación: 
    <a href='index.php'>Home</a>
</nav>
<hr/>