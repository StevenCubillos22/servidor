<?php
session_start(); 

include_once("./GestiTarea.php");
include_once("./config.php");

//me puedes mostrar tu index porfi
if (isset($_SESSION['id'])){
   
    header("Location: views/indice.php");
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Encabezado HTML -->
</head>
<body>
    <?php
    if (isset($_REQUEST["action"])) {
        $action = $_REQUEST["action"];
    } else {       
        echo "Muy buenas usuario Nº " . $_SESSION["id"] . "<br>";
        $action = "mostrarListaTareas";  // Acción por defecto que se realiza
    }

    $tareita = new GestiTarea();
    $tareita->$action();
/*
} else {
    header("Location: views/indice.php");
} */

?>

<hr>
<?php
echo "<p>¿Deseas salir? <a href='cerrarsesion.php'>Cerrar Sesión</a></p>";
?>
</body>
</html>