<?php

include_once "Model.php";
class Usuario extends Model {

    private $id;
    private $usuario;
    private $password;


    public function __construct() {
        $this->table = "usuarios";
        $this->idColumn = "id";
        parent::__construct();
    }

    

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getUsuario() {
        return $this->usuario;
    }

    public function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    public function getPassword() {
        return $this->password;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    

  // Inserta un libro. Devuelve 1 si tiene éxito o 0 si falla.
  public function insert($usuario, $password, $idPersona) {   
            
      return $this->db->dataManipulation("INSERT INTO usuarios (usuario, password, idPersona) VALUES ('$usuario', '$password', '$idPersona')");
  }

  
}