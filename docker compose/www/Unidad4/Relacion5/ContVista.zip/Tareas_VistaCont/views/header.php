<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>GestiTareas</title>
    
</head>
<body>
    <h1>GestiTarea</h1>
    <p>Crea, edita y modifica tareas con un solo clic</p>
    <hr>
