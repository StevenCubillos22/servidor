<?php
session_start();

include_once("./GestiTarea.php");
include_once("./config.php");

   // header("Location: views/index.html");
if (isset($_SESSION['id'])){
    

    if (isset($_REQUEST["action"])) {
        $action = $_REQUEST["action"];
    } else {
        echo "Muy buenas usuario Nº " . $_SESSION["id"] . "<br>";
        $action = "mostrarListaTareas";  // Acción por defecto que se realiza
    }
    

    $tareita = new GestiTarea();
    $tareita->$action();


} else {
    header("Location: views/index.html");
}


?>
<hr>
<?php
echo "<p>¿Deseas salir? <a href='cerrarsesion.php'>Cerrar Sesión</a></p>";
?>
</body>
</html>