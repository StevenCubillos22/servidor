<?php
include_once("clases/Tarea.php");
include_once("clases/Usuario.php");
include_once("clases/Model.php");

include_once("View.php");


class GestiTarea {

    private $db;             // Conexión con la base de datos
    private $tarea, $usuario;// Modelos

    public function __construct() {
        $this->tarea = new Tarea();
        $this->usuario = new Usuario();
    }


    function mostrarListaTareas() {

        $idUsuario = $_SESSION['id'];
        $data["listaTareas"] = $this->tarea->getAll($idUsuario); 
        View::render("tarea/all", $data);  // Asegúrate de pasar $data como segundo argumento a View::render
    }


    // --------------------------------- FORMULARIO ALTA DE TAREAS ----------------------------------------

    

     function formularioInsertarTarea() {
        $data["todosLosUsuarios"] = $this->usuario->getAll();
            $data["usuarioTarea"] = array();  // Array vacío (la tarea aún no tiene usuario asignados)
            View::render("Tarea/form", $data);
     }
    

    // --------------------------------- INSERTAR TAREA ----------------------------------------

    /*
    function insertarTarea($db){
    
        echo "<h1>Alta de Tareas</h1>";

        
        // Recuperamos todos los datos del formulario
        $titulo = $_POST["titulo"];
        $descripcion = $_POST["descripcion"];
        $usuario = $_POST["usuario"];

        // Creacion de objetos

        $nuevaTarea = new Tarea();
        $nuevaTarea->set_titulo($titulo);
        $nuevaTarea->set_descripcion($descripcion);



        $sql = "INSERT INTO tarea (titulo, descripcion) VALUES ('$titulo', '$descripcion')";
        $db->query($sql);
        
        if ($db->affected_rows == 1) {
            
            $idTarea = $db->insert_id;
            $idUsuario = $_SESSION['id'];
            
                $db->query("INSERT INTO usuarios_tarea(tarea, usuario) VALUES('$idTarea', '$usuario')");
            
            echo "Tarea insertado con éxito";
        } else {
            
            echo "Ha ocurrido un error al insertar la tarea. Por favor, inténtelo de nuevo.";
            

        }
        echo "<p><a href='tarea.view.php'>Volver</a></p>";
    }
    */

      function insertarTarea() {
            // Primero, recuperamos todos los datos del formulario
            $titulo = $_REQUEST["titulo"];
            $descripcion = $_REQUEST["descripcion"];      

            $result = $this->tarea->insert($titulo, $descripcion);
            if ($result == 1) {  
                // Si la inserción del tarea ha funcionado, continuamos insertando los autores, pero
                // necesitamos conocer el id del libro que acabamos de insertar
                $id = $this->tarea->getMaxId();
                // Ya podemos insertar todos los autores junto con el libro en "escriben"
               // $result = $this->tarea->insertAutores($idLibro, $autores);
                
            } 
            $data["listaTareas"] = $this->tarea->getAll();
            View::render("tarea/all", $data);

        } 

    // --------------------------------- BORRAR TAREA ----------------------------------------

    
      function borrarTarea() {
            // Recuperamos el id del libro que hay que borrar
            $idTarea = $_REQUEST["idTarea"];
            // Pedimos al modelo que intente borrar el libro
            $result = $this->tarea->deleteTarea($idTarea);
            $result = $this->tarea->deleteUsuariosTarea($idTarea);

 
            $data["listaTareas"] = $this->tarea->getAll();
            View::render("tarea/all", $data);

        }

    // --------------------------------- FORMULARIO MODIFICAR TAREAS ----------------------------------------



     function formularioModificarTarea() {
            // Recuperamos los datos de la tarea a modificar
            $idTarea = $_REQUEST["idTarea"];
            $data["tarea"] = $this->tarea->get($idTarea)[0];
            // Renderizamos la vista de inserción de libros, pero enviándole los datos del libro recuperado.
            // Esa vista necesitará la lista de todos los autores y, además, la lista
            // de los autores de este libro en concreto.
            View::render("tarea/form", $data);
        } 


    // --------------------------------- MODIFICAR TAREA ----------------------------------------

    function modificarTarea(){
    
        echo "<h1>Modificación de Tareas</h1>";

        // Recuperamos todos los datos del formulario
        $idTarea = $_REQUEST["idTarea"];
        $titulo = $_REQUEST["titulo"];
        $descripcion = $_REQUEST["descripcion"];
        

        //OBJETOS

        $tareaModificar = new Tarea();
        /*$tareaModificar->set_id($idTarea);*/
        $tareaModificar->set_Titulo($titulo);
        $tareaModificar->set_Descripcion($descripcion);

        // Pedimos al modelo que haga el update
        $result = $this->tarea->update($idTarea, $titulo, $descripcion);
           
        
        $data["listaTareas"] = $this->tarea->getAll();
        View::render("tarea/all", $data);

    }
        
       

}

    ?>