<!-- logueado.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
</head>
<body>
    <h1>Bienvenido a nuestra sesión.</h1><br>

    <img src="cafe.jpg" height=\"135px\" />
</body>
</html>
